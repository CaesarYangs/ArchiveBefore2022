
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class mainWindow {

    public static void main(String[] args) {
        LoginWindow l;
        JFrame Start = new JFrame("Start");
        Start.setSize(300,300);

        LoginWindow.LoginW(Start);
    }

}
