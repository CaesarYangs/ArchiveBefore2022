package Project2;

public interface Terrestrial {  //接口类定义
    int getLegNum();
}
