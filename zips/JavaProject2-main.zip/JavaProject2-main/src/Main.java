import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        LoginWindow l;
        JFrame Start = new JFrame("Start");
        Start.setSize(300,300);

        LoginWindow.LoginW(Start);
    }
}
