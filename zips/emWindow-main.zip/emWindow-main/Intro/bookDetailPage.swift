//
//  bookDetailPage.swift
//  Intro
//
//  Created by 杨业卿 on 2021/2/9.
//

import SwiftUI

struct bookDetailPage: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct bookDetailPage_Previews: PreviewProvider {
    static var previews: some View {
        bookDetailPage()
    }
}
