//
//  IntroApp.swift
//  Intro
//
//  Created by 杨业卿 on 2021/1/25.
//

import SwiftUI

@main
struct IntroApp: App {
    
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
        
    }
}
