#include<iostream>
#include"UI.h"
#include"user io.h"
void UserInterface::MainInterFace()
{
	std::cout << "------------------HELLO------------------" << std::endl;
	std::cout << "-This Is A Domainname Scearching Program-" << std::endl;
	std::cout << "-------Please Enter Domain Name----------" << std::endl;    
}

void UserInterface :: MainInterFace(){

}