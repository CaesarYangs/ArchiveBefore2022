#include"userio.h""
int main(void)
{

	souredfishIO sio;
	UserInterface ui;
	ui.GetIO(&sio);
	//sio.load();
	sio.domainName();
	sio.domainName();

	return 0;
}