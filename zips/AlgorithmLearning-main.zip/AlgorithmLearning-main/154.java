class Solution {
    public int findMin(int[] nums) {
        int l=
    }
}