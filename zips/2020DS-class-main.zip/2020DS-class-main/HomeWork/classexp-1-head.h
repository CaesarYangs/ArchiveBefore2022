//
// Created by 杨业卿 on 2020/10/4.
//

#ifndef HOMEWORK_CLASSEXP_1_HEAD_H
#define HOMEWORK_CLASSEXP_1_HEAD_H

using namespace std;




#endif //HOMEWORK_CLASSEXP_1_HEAD_H
