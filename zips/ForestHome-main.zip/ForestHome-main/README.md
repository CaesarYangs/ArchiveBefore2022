---
description: 林中小屋是什么？
---

# Description

2022年1月，Caesar经过了很多思考，反思，查找建议，最终将自己的学习模式迭代，这也是一次意义重大的改变。

林中小屋的意义便在于整理Caesar的全部读书成果，供自己使用。当然，如果足够好的话，能让更多的人从众受益。

That's it.&#x20;

Quite simple.
