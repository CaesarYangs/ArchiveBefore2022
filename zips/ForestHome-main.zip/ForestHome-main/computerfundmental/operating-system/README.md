# Operating System

### 2022.1

#### 第一版读书+笔记整理正在进行中。2022.1

<table><thead><tr><th align="center">Chapter</th><th data-type="number"></th><th data-type="checkbox">1st</th></tr></thead><tbody><tr><td align="center">绪论</td><td>20220123</td><td>true</td></tr><tr><td align="center">操作系统用户界面</td><td>null</td><td>false</td></tr><tr><td align="center">进程管理</td><td>null</td><td>false</td></tr><tr><td align="center">处理机调度</td><td>null</td><td>false</td></tr><tr><td align="center">存储管理</td><td>null</td><td>false</td></tr><tr><td align="center">文件系统</td><td>null</td><td>false</td></tr><tr><td align="center">设备管理</td><td>null</td><td>false</td></tr></tbody></table>
