---
description: Network
---

# Computer Network

### 2022.1

第一轮读书+笔记整理正在进行

<table><thead><tr><th></th><th data-type="number"></th><th data-type="checkbox">1st</th></tr></thead><tbody><tr><td>Introduction</td><td>20220120</td><td>true</td></tr><tr><td>Physical Layer</td><td>20220121</td><td>true</td></tr><tr><td>Data Link Layer</td><td>null</td><td>false</td></tr><tr><td>MAC Layer</td><td>null</td><td>false</td></tr><tr><td>Network Layer</td><td>null</td><td>false</td></tr><tr><td>Transport Layer</td><td>null</td><td>false</td></tr><tr><td>Application Layer</td><td>null</td><td>false</td></tr></tbody></table>
