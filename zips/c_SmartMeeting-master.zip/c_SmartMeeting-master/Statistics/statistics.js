function navDep(){
	window.location.href = "depStatistics.html";
}

function navSal(){
	window.location.href = "employeeStatistics.html";
}

function showStatistics(){
	// $('#myFrame').attr('src', "Statistics/employeeStatistics.html");
	window.history.go(-1);

}