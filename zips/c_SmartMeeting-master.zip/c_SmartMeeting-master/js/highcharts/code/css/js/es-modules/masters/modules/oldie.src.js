/**
 * @license @product.name@ JS v@product.version@ (@product.date@)
 * Old IE (v6, v7, v8) module for Highcharts v6+.
 *
 * (c) 2010-2017 Highsoft AS
 * Author: Torstein Honsi
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../modules/oldie.src.js';
